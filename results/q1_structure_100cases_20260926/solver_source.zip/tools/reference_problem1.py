"""Explicit historical baseline reference runner, not production entry."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from q1.reference_cli import main
if __name__=="__main__":raise SystemExit(main())
